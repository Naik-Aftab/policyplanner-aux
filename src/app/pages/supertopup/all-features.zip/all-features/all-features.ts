import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

type TabKey = 'includes' | 'excludes' | 'cashless' | 'claim' | 'addons';

interface PremiumOption {
  id: '1Y' | '2Y' | '3Y';
  label: string;
  amount: number;
  display: string;
  base?: number;
  discount?: number;
  payable?: number;
}

@Component({
  selector: 'app-all-features',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './all-features.html',
  styleUrls: ['./all-features.scss'],
})
export class AllFeatures implements OnInit {

  constructor(private sanitizer: DomSanitizer) {}

  /* -------------------- MAIN PLAN DATA -------------------- */
  selectedPlan: any = null;

  insurerLogo = '';
  insurerName = '';
  productName = '';
  proposalData = { productName: '' };

  insured = { self: '', pincode: '' };

  /* -------------------- PREMIUM DATA -------------------- */
  premiumOptions: PremiumOption[] = [];
  selectedTenure: PremiumOption | null = null;

  coverAmount = '';
  membersCovered = '';
  discount = 0;
  private totalPremiumOverride?: number;

  get basePremium(): number {
    return this.selectedTenure?.amount || 0;
  }

  get totalPremium(): number {
    if (this.totalPremiumOverride != null) return this.totalPremiumOverride;
    return this.basePremium - this.discount;
  }

  /* -------------------- TABS -------------------- */
  activeTab: TabKey = 'includes';
  setTab(tab: TabKey) {
    this.activeTab = tab;
  }

  includesList: string[] = [];
  excludesList: string[] = [];

  /* -------------------- YOUTUBE -------------------- */
  readonly youtubeId = '2g8VSYbV5ag';
  showYouTube = false;
  youtubeUrl?: SafeResourceUrl;

  startVideo() {
    if (this.showYouTube) return;
    const url = `https://www.youtube.com/embed/${this.youtubeId}?autoplay=1&rel=0`;
    this.youtubeUrl = this.sanitizer.bypassSecurityTrustResourceUrl(url);
    this.showYouTube = true;
  }

  /* -------------------- SHARE -------------------- */
  async sharePlan() {
    const navAny = navigator as Navigator & { share?: Function; clipboard?: any };

    const payload = {
      title: `${this.insurerName} ${this.productName}`,
      text: 'Check this health plan',
      url: window.location.href,
    };

    try {
      if (typeof navAny.share === 'function') return await navAny.share(payload);
    } catch {}

    try {
      await navigator.clipboard.writeText(window.location.href);
      alert('Link copied!');
    } catch {
      prompt('Copy:', window.location.href);
    }
  }

  /* -------------------- TENURE CLICK -------------------- */
  chooseTenure(opt: PremiumOption) {
    this.selectedTenure = opt;
    this.discount = opt.discount ?? 0;
    this.totalPremiumOverride = opt.payable ?? (opt.amount - this.discount);
  }

  /* -------------------- INIT -------------------- */
  ngOnInit(): void {
console.log("🔥 FULL selectedPlan DATA:", this.selectedPlan);

    const navState = history.state as { selectedPlan?: any };
    this.selectedPlan = navState?.selectedPlan ?? null;

    if (!this.selectedPlan) return;

    /* ---------- Company + Plan Name ---------- */
    const companyName = this.selectedPlan.company?.company_name || '';
    const planName =
      this.selectedPlan.planName ||
      this.selectedPlan.plan?.plan_name ||
      '';

    this.insurerName = companyName;
    this.productName = planName;
    this.proposalData.productName = `${companyName} ${planName}`.trim();

    /* ---------- Logo ---------- */
    const logoUrl =
      this.selectedPlan.company?.logo ||
      this.selectedPlan.logo;

    if (logoUrl) {
      this.insurerLogo = '/assets/quote/' + logoUrl;
    }

    /* ----------------- MULTI-YEAR PREMIUM ----------------- */
    const base1 = Number(this.selectedPlan.totalBasePremium ?? 0);
    const disc1 = Number(this.selectedPlan.totalDiscount ?? 0);
    const pay1  = Number(this.selectedPlan.totalPayablePremium ?? base1 - disc1);

    const base2 = Number(this.selectedPlan.totalBasePremium2Y ?? base1 * 2);
    const disc2 = Number(this.selectedPlan.totalDiscount2Y ?? disc1 * 2);
    const pay2  = Number(this.selectedPlan.totalPayablePremium2Y ?? base2 - disc2);

    const base3 = Number(this.selectedPlan.totalBasePremium3Y ?? base1 * 3);
    const disc3 = Number(this.selectedPlan.totalDiscount3Y ?? disc1 * 3);
    const pay3  = Number(this.selectedPlan.totalPayablePremium3Y ?? base3 - disc3);

    this.premiumOptions = [
      { id: '1Y', label: '1 Year', amount: base1, display: this.formatINR(pay1), base: base1, discount: disc1, payable: pay1 },
      { id: '2Y', label: '2 Year', amount: base2, display: this.formatINR(pay2), base: base2, discount: disc2, payable: pay2 },
      { id: '3Y', label: '3 Year', amount: base3, display: this.formatINR(pay3), base: base3, discount: disc3, payable: pay3 },
    ];

    /* Select default: 1Y */
    this.selectedTenure = this.premiumOptions[0];
    this.discount = this.selectedTenure.discount ?? 0;
    this.totalPremiumOverride = this.selectedTenure.payable ?? 0;

    /* ----------------- COVER AMOUNT ----------------- */
    const si = this.selectedPlan.coverAmount;
    if (si) this.coverAmount = '₹ ' + Number(si).toLocaleString('en-IN');

    /* ----------------- AGE & PINCODE ----------------- */
    const age =
      this.selectedPlan.eldestActualAge ||
      this.selectedPlan.eldestLookupAge;

    if (age) this.insured.self = `Self: ${age} years`;

    const pincode = this.selectedPlan.pincode;
    if (pincode) this.insured.pincode = `Pincode: ${pincode}`;

    /* ----------------- MEMBERS ----------------- */
    const adults = this.selectedPlan.noOfAdults ?? 0;
    const children = this.selectedPlan.noOfChildren ?? 0;
    this.membersCovered = `${adults} Adults, ${children} Children`;

    /* ----------------- INCLUDES / EXCLUDES ----------------- */
    const features = this.selectedPlan.features ?? [];

    this.includesList = features
      .map((f: any) => f.includes)
      .filter((txt: any) => txt);

    this.excludesList = features
      .map((f: any) => f.excludes)
      .filter((txt: any) => txt);
  }

  /* -------------------- INR FORMATTER -------------------- */
  private formatINR(value: number): string {
    return '₹' + Number(value || 0).toLocaleString('en-IN');
  }
}
