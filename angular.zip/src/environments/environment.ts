export const environment = {
  production: false,
  apiUrl: 'https://policyplanner.com/health-insurance/'
};
